from sklearn.model_selection import train_test_split
import pandas as pd
from sklearn.model_selection import learning_curve
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt
from sklearn.metrics import make_scorer
import numpy as np
import matplotlib.patches as mpatches
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder

SEED=42

def preprocess_titanic():
    df = pd.read_csv('datasets/titanic.csv')
    df.drop(labels=["PassengerId", "Name", "Ticket", "Cabin"], axis=1, inplace=True)
    df = pd.get_dummies(df, columns=['Sex', "Embarked"])
    df.Age = df.Age.fillna(df.Age.mean())
    column_list = df.columns.values.tolist()
    y = df["Survived"].values.tolist()
    column_list.remove("Survived")
    X = df[column_list].values.tolist()
    X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                    stratify=y,
                                                    random_state=42,
                                                    shuffle=True,
                                                    test_size=0.20)
    scaler = MinMaxScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    one_hot = OneHotEncoder()

    y_train = one_hot.fit_transform(np.array(y_train).reshape(-1, 1)).todense()
    y_test = one_hot.transform(np.array(y_test).reshape(-1, 1)).todense()
    return X_train, X_test, y_train, y_test

def preprocess_iris():
    df = pd.read_csv('datasets/iris.csv')
    df = df.drop(["Id"],axis=1)
    df.Species = df.Species.astype("category")
    df.Species = df.Species.cat.codes
    column_list = df.columns.values.tolist()
    y = df["Species"].values.tolist()
    column_list.remove("Species")
    
    X = df[column_list].values.tolist()
    X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                    stratify=y,
                                                    random_state=42,
                                                    shuffle=True,
                                                    test_size=0.20)
    # scaler = MinMaxScaler()
    # X_train = scaler.fit_transform(X_train)
    # X_test = scaler.transform(X_test)
    one_hot = OneHotEncoder()

    y_train = one_hot.fit_transform(np.array(y_train).reshape(-1, 1)).todense()
    y_test = one_hot.transform(np.array(y_test).reshape(-1, 1)).todense()
    return X_train, X_test, y_train, y_test
