### How To
- Download from https://github.com/swinton7/ML/blob/main/mlhw4.zip
- Install conda https://conda.io/projects/conda/en/latest/user-guide/install/index.html
- create environment using the environment file by running this command `conda env create --name mlhw4 --file=environment.yml`
- Extract zip file into a folder
- If you are using visual studio, you should be able to select the conda environment as kernel and run each notebook
- or spin up a new jupyter lab/notebook instance and run each notebook there
