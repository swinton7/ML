from sklearn.model_selection import train_test_split
import pandas as pd
from sklearn.model_selection import learning_curve
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt
from sklearn.metrics import make_scorer
import numpy as np
import matplotlib.patches as mpatches
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from sklearn.metrics import mean_squared_error

SEED=42

def preprocess_titanic(normalized=True):
    df = pd.read_csv('datasets/titanic.csv')
    df.drop(labels=["PassengerId", "Name", "Ticket", "Cabin"], axis=1, inplace=True)
    df = pd.get_dummies(df, columns=['Sex', "Embarked"])
    df.Age = df.Age.fillna(df.Age.mean())
    column_list = df.columns.values.tolist()
    labels = ["Not Survived", "Survived"]
    y = df["Survived"].values.tolist()
    column_list.remove("Survived")
    X = df[column_list].values.tolist()
    X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                    stratify=y,
                                                    random_state=42,
                                                    shuffle=True,
                                                    test_size=0.20)
    if normalized:
        scaler = MinMaxScaler()
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)

    y_train = np.array(y_train).reshape(-1, 1)
    y_test = np.array(y_test).reshape(-1, 1)
    return X_train, X_test, y_train, y_test, labels

def preprocess_iris(normalized=True):
    df = pd.read_csv('datasets/iris.csv')
    df = df.drop(["Id"],axis=1)
    labels = pd.unique(df.Species).tolist()
    df.Species = df.Species.apply(lambda x: labels.index(x))
    column_list = df.columns.values.tolist()
    y = df["Species"].values.tolist()
    column_list.remove("Species")
    
    X = df[column_list].values.tolist()
    X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                    stratify=y,
                                                    random_state=42,
                                                    shuffle=True,
                                                    test_size=0.20)
    if normalized:
        scaler = MinMaxScaler()
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)

    y_train = np.array(y_train).reshape(-1, 1)
    y_test = np.array(y_test).reshape(-1, 1)
    return X_train, X_test, y_train, y_test, labels
