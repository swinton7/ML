### How To ###
- Download zip file containing code and dataset from here https://github.com/f52d9e4d-863f-44e0-81e9-b4e5286d4dab
or visit my gitlab and download the file https://github.com/swinton7/ML/blob/main/mlhw1.zip
- Extract to a folder and cd the folder
- run this command `conda env create --name mlhw1 --file=environment.yml`
- Spawn a jupyter lab
- Enjoy
