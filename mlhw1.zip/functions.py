from sklearn.model_selection import train_test_split
import pandas as pd
from sklearn.model_selection import learning_curve
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt
from sklearn.metrics import make_scorer
import numpy as np
import matplotlib.patches as mpatches

SEED=42

def preprocess_titanic():
    df = pd.read_csv('datasets/titanic.csv')
    df.drop(labels=["PassengerId", "Name", "Ticket", "Cabin"], axis=1, inplace=True)
    df = pd.get_dummies(df, columns=['Sex', "Embarked"])
    df.Age = df.Age.fillna(df.Age.mean())
    column_list = df.columns.values.tolist()
    y = df["Survived"].values.tolist()
    column_list.remove("Survived")
    X = df[column_list].values.tolist()
    X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                    stratify=y,
                                                    random_state=42,
                                                    shuffle=True,
                                                    test_size=0.20) 
    return X_train, X_test, y_train, y_test

def preprocess_iris():
    df = pd.read_csv('datasets/iris.csv')
    df = df.drop(["Id"],axis=1)
    df.Species = df.Species.astype("category")
    df.Species = df.Species.cat.codes
    column_list = df.columns.values.tolist()
    y = df["Species"].values.tolist()
    column_list.remove("Species")
    X = df[column_list].values.tolist()
    X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                    stratify=y,
                                                    random_state=42,
                                                    shuffle=True,
                                                    test_size=0.20)
    return X_train, X_test, y_train, y_test

def produce_learning_curve(estimator, X, y, scoring="roc_auc"):
    train_sizes_abs, train_scores, test_scores, fit_times, score_times = learning_curve(return_times=True, random_state=SEED, shuffle=True, cv=5, train_sizes=[0.2, 0.4, 0.6, 0.8, 1.0], estimator=estimator, X=X, y=y, scoring=scoring)
    return train_sizes_abs, np.mean(train_scores, axis=1), np.mean(test_scores, axis=1), np.mean(fit_times, axis=1), np.mean(score_times, axis=1)

def produce_validation_curve(estimator, X, y, scoring="roc_auc"):
    train_sizes_abs, train_scores, test_scores, fit_times, score_times = learning_curve(return_times=True, random_state=SEED, shuffle=True, cv=5, train_sizes=[1.0], estimator=estimator, X=X, y=y, scoring=scoring)
    return train_sizes_abs, np.mean(train_scores, axis=1), np.mean(test_scores, axis=1), np.mean(fit_times, axis=1), np.mean(score_times, axis=1)


def trigger_validate(estimator, X, y, class_type='binary'):
    if class_type == 'binary':
        y_pred = estimator.predict_proba(X)[:, 1]
        multi_class='raise'
    else:
        y_pred = estimator.predict_proba(X)
        multi_class='ovo'
    result = roc_auc_score(y, y_pred, multi_class=multi_class)
    return result

def generate_line_graph(X,y1,y2,x_title,y_title,title, types=1):
    COLOR_Y1 = "#69b3a2"
    COLOR_Y2 = "#3399e6"
    fig, ax = plt.subplots(figsize=(6, 4))

    # Instantiate a second axes that shares the same x-axis
    ax.plot(X, y1, color=COLOR_Y1)
    ax.plot(X, y2, color=COLOR_Y2)
    Y1_PATCHES = mpatches.Patch(color=COLOR_Y1, label="train")
    Y2_PATCHES = mpatches.Patch(color=COLOR_Y2, label="test")
    
    ax.set_xlabel(x_title)
    ax.set_ylabel(y_title)

    ax.grid(linestyle='--')
    ax.legend(handles=[Y1_PATCHES, Y2_PATCHES], loc='upper center', bbox_to_anchor=(1.1, 1.0),
          ncol=1)
    fig.suptitle(title)
    fig.savefig(f"figures/{title.lower().replace(" ","_")}__{y_title.lower()}", bbox_inches="tight")

def generate_bar_graph(X,y1,y2,x_title,y_title,title):
    COLOR_Y1 = "#69b3a2"
    COLOR_Y2 = "#3399e6"
    fig, ax = plt.subplots(figsize=(6, 4))

    # Instantiate a second axes that shares the same x-axis
    x_axis = np.arange(len(X))
    ax.bar(X, y1, color=COLOR_Y1, width=-0.2, align='edge')
    ax.bar(X, y2, color=COLOR_Y2, width=0.2, align='edge')
    Y1_PATCHES = mpatches.Patch(color=COLOR_Y1, label="train")
    Y2_PATCHES = mpatches.Patch(color=COLOR_Y2, label="test")
    
    ax.set_xlabel(x_title)
    ax.set_ylabel(y_title)

    ax.grid(linestyle='--')
    ax.legend(handles=[Y1_PATCHES, Y2_PATCHES], loc='upper center', bbox_to_anchor=(1.1, 1.0),
          ncol=1, facecolor="white")
    fig.suptitle(title)
    fig.savefig(f"figures/{title.lower().replace(" ","_")}__{y_title.lower()}", bbox_inches="tight")

def generate_learning_curve(estimator, X_train, y_train, X_test, y_test, x_title, title, scoring="roc_auc"):
    train_sizes_abs, train_scores, test_scores, fit_times, score_times = produce_learning_curve(estimator, X_train, y_train, scoring)
    generate_line_graph(train_sizes_abs,train_scores,test_scores,x_title, "rocauc",title)
    generate_line_graph(train_sizes_abs,fit_times,score_times,x_title, "wall clock",title)
    print("train wall clock:",fit_times[-1])
    print("test wall clock:",score_times[-1])
    estimator.fit(X_train, y_train)
    if scoring == "roc_auc":
        print("train roc auc: ",trigger_validate(estimator, X_train, y_train, "binary"))
        print("test roc auc:",trigger_validate(estimator, X_test, y_test, "binary"))
    else:
        print("train roc auc: ",trigger_validate(estimator, X_train, y_train, "multiclass"))
        print("test roc auc:",trigger_validate(estimator, X_test, y_test, "multiclass"))

def generate_validation_curve(estimators, params, X_train, y_train, X_test, y_test,x_title, title,graph_type='line',scoring="roc_auc"):
    train_scoress = []
    test_scoress = []
    fit_timess = []
    score_timess = []
    for estimator in estimators:
        train_sizes_abs, train_scores, test_scores, fit_times, score_times = produce_validation_curve(estimator, X_train, y_train, scoring)
        train_scoress.append(train_scores[0])
        test_scoress.append(test_scores[0])
        fit_timess.append(fit_times[0])
        score_timess.append(score_times[0])
    
    if graph_type=='line':
        generate_line_graph(params,train_scoress,test_scoress,x_title, "rocauc",title)
        generate_line_graph(params,fit_timess,score_timess,x_title,"wall clock",title)
    elif graph_type=='bar':
        generate_bar_graph(params,train_scoress,test_scoress,x_title, "rocauc",title)
        generate_bar_graph(params,fit_timess,score_timess,x_title,"wall clock",title)
    else:
        raise ValueError("Not Implemented")